package TestNG_project;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Page_object.Add_CartQty;
import Page_object.Cart_Page;
import Page_object.Incorrect_Login;
import Page_object.Log_Out;
import Page_object.Login_Page;
import Page_object.PlaceOrder;
import Page_object.Product_Page;
import Page_object.Product_Sorting;

public class SwagLabTestNG {

WebDriver driver;
	
	Login_Page lp;
	Cart_Page cp;
	PlaceOrder po;
	Log_Out lo;
	Incorrect_Login il;
	Add_CartQty acq;
	Product_Page pp;
	Product_Sorting ps;
	
	
	@BeforeSuite
	public void setUp() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		lp = new Login_Page(driver);
		cp = new Cart_Page(driver);
		po = new PlaceOrder(driver);
		lo = new Log_Out(driver);
		il = new Incorrect_Login(driver);
		acq = new Add_CartQty(driver);
		pp = new Product_Page(driver);
		ps = new Product_Sorting(driver);
		
	}
	
	
	@Test(priority = 1)
	public void Login() throws InterruptedException {

	lp.url();
	lp.login();
	lp.closeBrowser();
	
	}
	
	@Test(priority = 2)
	public void Cart() throws InterruptedException {

	cp.url();
	cp.login();
	cp.addToCart();
	cp.getCartBadgeCount();
	cp.goToCart();
	cp.removeFromCart();
	cp.closeBrowser();
	
	}
	
	@Test(priority = 3)
	public void placeOrder() throws InterruptedException, IOException {

	po.url();
	po.login();
	po.addToCart();
	po.goToCart();
	po.checkOut();
	po.InfoDetails();
	po.displayCartDetails();
	
	}
	
	@Test(priority = 4)
	public void IncorrectLogin() {

	lo.url();
	lo.login();
	lo.logout();
	
	}
	
	@Test(priority = 5)
	public void LogOut() {

	il.url();
	il.login();
	
	}
	
	@Test(priority = 6)
	public void AddCartQty() {

	acq.url();
	acq.login();
	acq.addToCart();
	acq.getCartBadgeCount();
	acq.goToCart();
	acq.addQty();
	
	}
	
	@Test(priority = 7)
	public void ProductPage() {
		
		pp.url();
		pp.login();
		pp.SortFunctionality();
		pp.getFirstProductTitle();
		pp.ProductList();
	
	
	}
	
	@Test(priority = 8)
	public void ProductSorting() {
		
		ps.url();
		ps.login_detail();
		ps.SortFunctionality();
		ps.addTocart();
		ps.verifyCart();
		ps.checkOut();
		ps.orderConfirmation();
	
	}

}
